export default function Notice() {
    return <div>Notice</div>;
}
