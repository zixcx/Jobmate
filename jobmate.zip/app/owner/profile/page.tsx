export default function OwnerProfile() {
    return <div>Owner Profile</div>;
}
