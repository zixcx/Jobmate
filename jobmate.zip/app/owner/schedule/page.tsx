export default function OwnerSchedule() {
    return <div>Owner Schedule</div>;
}
