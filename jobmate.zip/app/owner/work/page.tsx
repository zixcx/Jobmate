export default function OwnerWork() {
    return <div>Owner Work</div>;
}
