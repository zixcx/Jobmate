import dayjs from "dayjs";

export default function getSchedule(date: dayjs.ConfigType) {
    return {};
}
