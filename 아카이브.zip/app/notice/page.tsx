// ./app/notice/page.tsx
export default function Notice() {
    return <div>Notice</div>;
}
